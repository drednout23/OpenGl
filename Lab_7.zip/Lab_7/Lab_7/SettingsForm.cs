﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Lab_7
{
    public partial class SettingsForm : Form
    {
        private const string RegistryKey = "Software\\Lab_7.exe";

        public SettingsForm()
        {
            InitializeComponent();
        }

        private void SettingsForm_Load(object sender, EventArgs e)
        {
            Debug.WriteLine("Loading screen saver's settings...");

            // Загрузка настроек из реестра
            string animationSpeed = LoadSettingsFromRegistry("AnimationSpeed") ?? "1.0";
            string shapeCount = LoadSettingsFromRegistry("ShapeCount") ?? "300";

            // Создаём элементы управления (TextBox'ы) динамически
            var txtAnimationSpeed = new TextBox
            {
                Text = animationSpeed,
                Name = "txtAnimationSpeed",
                Location = new System.Drawing.Point(20, 20),
                Width = 200
            };
            var txtShapeCount = new TextBox
            {
                Text = shapeCount,
                Name = "txtShapeCount",
                Location = new System.Drawing.Point(20, 60),
                Width = 200
            };

            // Надписи
            this.Controls.Add(new Label
            {
                Text = "Animation Speed:",
                Location = new System.Drawing.Point(20, 0),
                AutoSize = true
            });
            this.Controls.Add(txtAnimationSpeed);
            this.Controls.Add(new Label
            {
                Text = "Shape Count:",
                Location = new System.Drawing.Point(20, 40),
                AutoSize = true
            });
            this.Controls.Add(txtShapeCount);

            // Кнопка "Save"
            var btnSave = new Button
            {
                Text = "Save",
                Location = new System.Drawing.Point(20, 100),
                Width = 80
            };
            btnSave.Click += (s, ev) =>
            {
                SaveSettingsToRegistry("AnimationSpeed", txtAnimationSpeed.Text);
                SaveSettingsToRegistry("ShapeCount", txtShapeCount.Text);
                MessageBox.Show("Settings saved!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            };
            this.Controls.Add(btnSave);
        }

        private void SettingsForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Debug.WriteLine("Saving screen saver's settings...");
        }

        // Сохранение в реестр
        public static void SaveSettingsToRegistry(string key, string value)
        {
            using (var registryKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
            {
                if (registryKey != null)
                {
                    registryKey.SetValue(key, value);
                }
                else
                {
                    throw new Exception("Unable to access registry key.");
                }
            }
        }

        // Загрузка из реестра
        public static string LoadSettingsFromRegistry(string key)
        {
            using (var registryKey = Registry.CurrentUser.OpenSubKey(RegistryKey))
            {
                if (registryKey != null && registryKey.GetValue(key) != null)
                {
                    return registryKey.GetValue(key).ToString();
                }
                else
                {
                    return null;
                }
            }
        }
    }
}
