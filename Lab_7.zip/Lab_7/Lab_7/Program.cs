﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Lab_7
{
    /// <summary>
    /// Главный класс скринсейвера (partial в исходном шаблоне).
    /// Теперь собран в одном файле, чтобы не было конфликтов.
    /// </summary>
    public static partial class Program
    {
        /// <summary>
        /// Режимы работы скринсейвера (из исходного шаблона).
        /// </summary>
        public enum Mode
        {
            Unknown,
            Settings,
            ModalSettings,
            Preview,
            Run
        }

        /// <summary>
        /// Текущее состояние работы (устанавливается после парсинга командной строки).
        /// </summary>
        public static Mode mode = Mode.Unknown;

        /// <summary>
        /// Хендл родительского окна при /p <HWND> (Windows передаёт).
        /// </summary>
        public static IntPtr parentWnd = IntPtr.Zero;

        /// <summary>
        /// Хендл owner-окна при /c:<HWND> (Windows передаёт).
        /// </summary>
        public static IntPtr ownerWnd = IntPtr.Zero;

        /// <summary>
        /// Нужен, чтобы в OpenGL-контроле обращаться к Program.DesignMode.
        /// Если не нужно — убираем все ссылки из OpenGL-кода и отсюда.
        /// </summary>
        public static bool DesignMode { get; set; } = false;

        /// <summary>
        /// Точка входа приложения (ScreenSaver).
        /// </summary>
        [STAThread]
        static void Main(string[] cmd)
        {
            // Обычно для скринсейвера не включаем дизайн-режим
            DesignMode = false;

            // Стандартная настройка WinForms
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Парсим командную строку и определяем режим
            mode = Selector(cmd);

            // В зависимости от режима — делаем свою логику
            switch (mode)
            {
                case Mode.Run:
                    // /s: запустить заставку (полноэкранную)
                    ShowSaver();
                    break;

                case Mode.Preview:
                    // /p <HWND>: превью в родительском окошке
                    // (или своя логика превью)
                    ShowPreview();
                    break;

                case Mode.Settings:
                    // /c без параметров: просто открыть окно настроек
                    Application.Run(new SettingsForm());
                    break;

                case Mode.ModalSettings:
                    // /c:<HWND>: открыть настройки модально к ownerWnd
                    ShowModalSetting();
                    break;

                default:
                    // Unknown — ругаемся или делаем что-то по умолчанию
                    if (cmd.Length > 0)
                    {
                        MessageBox.Show(
                            "Unknown command: " + cmd[0]
                            + Environment.NewLine
                            + "Use /s, /c, /p, etc.",
                            "Info"
                        );
                    }
                    else
                    {
                        MessageBox.Show(
                            "No command specified. Use /s, /c, /p, etc.",
                            "Info"
                        );
                    }
                    break;
            }
        }

        /// <summary>
        /// Разбор аргументов командной строки.
        /// </summary>
        internal static Mode Selector(string[] cmd)
        {
            // Если нет аргументов, пусть будет Settings
            if (cmd == null || cmd.Length == 0)
                return Mode.Settings;

            string arg = cmd[0].Trim().ToLower();

            // Если меньше 2 символов, тоже в Unknown
            if (arg.Length < 2) return Mode.Unknown;

            // Смотрим первые 2 символа: /s, /p, /c, ...
            switch (arg.Substring(0, 2))
            {
                case "/s": return Mode.Run;
                case "/p": return ModePreview(cmd);
                case "/c": return ModeSetting(cmd);
                // /a и т.д. (если нужно) — по аналогии
                default: return Mode.Unknown;
            }
        }

        /// <summary>
        /// Обработка /p <HWND>
        /// </summary>
        private static Mode ModePreview(string[] cmd)
        {
            // Если просто "/p" без HWND — даём своё превью, без встраивания
            if (cmd.Length == 1)
            {
                parentWnd = IntPtr.Zero;
                return Mode.Preview;
            }

            // Иначе, если передали HWND, делаем стандартное встраивание
            if (long.TryParse(cmd[1], out long val))
            {
                parentWnd = new IntPtr(val);
                return Mode.Preview;
            }

            // Если не Parse-ится, считаем Unknown
            return Mode.Unknown;
        }


        /// <summary>
        /// Обработка /c[:<HWND>]
        /// </summary>
        private static Mode ModeSetting(string[] cmd)
        {
            // /c:123456
            var c = cmd[0].Split(':');
            if (c.Length == 1)
            {
                // Просто /c
                return Mode.Settings;
            }

            // Пытаемся прочесть owner-окно
            if (long.TryParse(c[1], out long h))
            {
                ownerWnd = new IntPtr(h);
                return Mode.ModalSettings;
            }
            else
            {
                return Mode.Unknown;
            }
        }

        /// <summary>
        /// Запуск заставки (пример: полноэкранно на всех мониторах)
        /// </summary>
        internal static void ShowSaver()
        {
            Cursor.Hide();

            foreach (Screen screen in Screen.AllScreens)
            {
                var screensaver = new MainForm();
                screensaver.Bounds = screen.Bounds;
                screensaver.Show();
            }

            // Запускаем обработку сообщений
            Application.Run();
        }

        /// <summary>
        /// Показываем настройки в «модальном» режиме к ownerWnd (при /c:<HWND>)
        /// </summary>
        internal static void ShowModalSetting()
        {
            WindowHandleWrapper wnd = new WindowHandleWrapper(ownerWnd);
            var d = new SettingsForm();
            if (d is Form)
                d.ShowDialog(wnd);
        }

        /// <summary>
        /// Логика для /p <HWND> (превью)
        /// </summary>
        private static void ShowPreview()
        {
            // Если parentWnd == IntPtr.Zero, это значит: "/p" без второго аргумента
            if (parentWnd == IntPtr.Zero)
            {
                // 1) Покажем "маленькое окно-превью", 
                //    например, размером 400×300, с рамкой и заголовком.
                using (var previewForm = new Form()) // или MainForm(), как удобнее
                {
                    previewForm.Text = "Preview ScreenSaver";
                    previewForm.Width = 400;
                    previewForm.Height = 300;
                    previewForm.StartPosition = FormStartPosition.CenterScreen;

                    // Вставим ваш RenderControl (или что там рисует заставку)
                    var previewControl = new RenderControl();
                    previewControl.Dock = DockStyle.Fill;

                    previewForm.Controls.Add(previewControl);

                    // Модально, чтобы пользователь не переключался
                    previewForm.ShowDialog();
                }
            }
            else
            {
                // 2) Если parentWnd != IntPtr.Zero, 
                //    это классическая схема "встраивания" в окно с хендлом parentWnd.
                var previewForm = new MainForm
                {
                    // Чтобы не иметь рамки 
                    FormBorderStyle = FormBorderStyle.None,
                    TopLevel = false, // делаем форму не-верхнеуровневой
                };

                // Покажем, как дочерний элемент для parentWnd.
                WindowHandleWrapper w = new WindowHandleWrapper(parentWnd);
                previewForm.Show(w);

                // Обычно для /p не вызывается Application.Run() второй раз,
                // но если вы хотите запустить цикл сообщений, можно:
                Application.Run();
            }
        }

    }
}
