﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.Win32; // Для работы с реестром

namespace Lab_7
{
    public partial class RenderControl : OpenGL
    {
        private List<MovingShape> shapes = new List<MovingShape>();
        private Random random = new Random();

        private double boundaryX = 10.0;
        private double boundaryY = 10.0;
        private const double boundaryZ = 10.0;

        private const string RegistryKey = "Software\\Lab_7.exe";

        public RenderControl()
        {
            InitializeComponent();
            UpdateBoundaries();
            Resize += OnResize;
        }

        #region Методы сохранения/загрузки настроек
        public void SaveSettingsToRegistry(string key, string value)
        {
            using (var registryKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
            {
                registryKey?.SetValue(key, value);
            }
        }

        public string LoadSettingsFromRegistry(string key)
        {
            using (var registryKey = Registry.CurrentUser.OpenSubKey(RegistryKey))
            {
                return registryKey?.GetValue(key)?.ToString() ?? string.Empty;
            }
        }

        public static void SaveSettingsToRegistryStatic(string key, string value)
        {
            using (var registryKey = Registry.CurrentUser.CreateSubKey(RegistryKey))
            {
                registryKey?.SetValue(key, value);
            }
        }

        public static string LoadSettingsFromRegistryStatic(string key)
        {
            using (var registryKey = Registry.CurrentUser.OpenSubKey(RegistryKey))
            {
                return registryKey?.GetValue(key)?.ToString() ?? string.Empty;
            }
        }
        #endregion

        #region Инициализация OpenGL и загрузка фигур
        private void OnContextCreated(object sender, EventArgs e)
        {
            // Включаем z-буфер
            glEnable(GL_DEPTH_TEST);

            // Фоновый цвет
            glClearColor(Color.Black);

            // Генерируем фигуры (учитывая настройки)
            InitializeShapes();
        }

        private void InitializeShapes()
        {
            // Считываем ShapeCount
            var shapeCountString = LoadSettingsFromRegistryStatic("ShapeCount");
            int shapeCount = 300; // по умолчанию

            if (!string.IsNullOrEmpty(shapeCountString) && int.TryParse(shapeCountString, out int parsedShapeCount))
            {
                shapeCount = parsedShapeCount;
            }

            // Считываем AnimationSpeed
            var animationSpeedString = LoadSettingsFromRegistryStatic("AnimationSpeed");
            double animationSpeed = 1.0;

            if (!string.IsNullOrEmpty(animationSpeedString) && double.TryParse(animationSpeedString, out double parsedSpeed))
            {
                animationSpeed = parsedSpeed;
            }

            // Очищаем старые
            shapes.Clear();

            // Генерируем шары/кубы/пирамиды/фракталы/сложные треугольники
            // enum ShapeType имеет 5 вариантов (0..4),
            // так что random.Next(0, 5) даёт числа [0..4].
            for (int i = 0; i < shapeCount; i++)
            {
                var st = (ShapeType)random.Next(0, 5);
                // (Cube=0, Sphere=1, Pyramid=2, Fractal=3, ComplexTriangle=4)

                var shape = new MovingShape
                {
                    X = random.NextDouble() * boundaryX * 2 - boundaryX,
                    Y = random.NextDouble() * boundaryY * 2 - boundaryY,
                    Z = random.NextDouble() * boundaryZ * 2 - boundaryZ,

                    DX = (random.NextDouble() * 0.2 - 0.1) * animationSpeed,
                    DY = (random.NextDouble() * 0.2 - 0.1) * animationSpeed,
                    DZ = (random.NextDouble() * 0.2 - 0.1) * animationSpeed,

                    Size = random.NextDouble() * 1.5 + 0.3,
                    Rotation = random.NextDouble() * 360.0,
                    RotationSpeed = random.NextDouble() * 3.0 - 1.5,
                    Color = new double[]
                    {
                        random.NextDouble(),
                        random.NextDouble(),
                        random.NextDouble()
                    },
                    ShapeType = st,

                    // Случайная ось вращения (RotAxisX/Y/Z).
                    RotAxisX = random.NextDouble() * 2 - 1, // от -1 до +1
                    RotAxisY = random.NextDouble() * 2 - 1,
                    RotAxisZ = random.NextDouble() * 2 - 1
                };

                // Нормализуем ось, чтобы не было проблем с очень маленькой длиной
                double length = Math.Sqrt(shape.RotAxisX * shape.RotAxisX
                                       + shape.RotAxisY * shape.RotAxisY
                                       + shape.RotAxisZ * shape.RotAxisZ);
                if (length < 0.0001) length = 1.0;
                shape.RotAxisX /= length;
                shape.RotAxisY /= length;
                shape.RotAxisZ /= length;

                shapes.Add(shape);
            }
        }
        #endregion

        #region Отрисовка
        private void OnRender(object sender, EventArgs e)
        {
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glLoadIdentity();

            // Настройка проекции
            glViewport(0, 0, Width, Height);
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            gluPerspective(45.0, (double)Width / Height, 0.1, 100.0);

            glMatrixMode(GL_MODELVIEW);

            // "Камеру" двинем подальше
            glTranslated(0.0, 0.0, -50.0);

            // Рисуем всё
            DrawMovingShapes();
            DrawBoundaryLimits();
        }

        private void DrawMovingShapes()
        {
            foreach (var shape in shapes)
            {
                // Двигаем фигуру
                shape.X += shape.DX;
                shape.Y += shape.DY;
                shape.Z += shape.DZ;
                shape.Rotation += shape.RotationSpeed;

                // Проверяем границы (отражение)
                if (shape.X - shape.Size < -boundaryX)
                {
                    shape.X = -boundaryX + shape.Size;
                    shape.DX = -shape.DX;
                }
                if (shape.X + shape.Size > boundaryX)
                {
                    shape.X = boundaryX - shape.Size;
                    shape.DX = -shape.DX;
                }

                if (shape.Y - shape.Size < -boundaryY)
                {
                    shape.Y = -boundaryY + shape.Size;
                    shape.DY = -shape.DY;
                }
                if (shape.Y + shape.Size > boundaryY)
                {
                    shape.Y = boundaryY - shape.Size;
                    shape.DY = -shape.DY;
                }

                if (shape.Z - shape.Size < -boundaryZ)
                {
                    shape.Z = -boundaryZ + shape.Size;
                    shape.DZ = -shape.DZ;
                }
                if (shape.Z + shape.Size > boundaryZ)
                {
                    shape.Z = boundaryZ - shape.Size;
                    shape.DZ = -shape.DZ;
                }

                // Отрисовка
                glPushMatrix();

                // Перемещаем в позицию
                glTranslated(shape.X, shape.Y, shape.Z);

                // Вращаем вокруг собственной оси (RotAxisX,Y,Z)
                glRotated(shape.Rotation, shape.RotAxisX, shape.RotAxisY, shape.RotAxisZ);

                // Цвет
                glColor3d(shape.Color[0], shape.Color[1], shape.Color[2]);

                // Тип фигуры
                switch (shape.ShapeType)
                {
                    case ShapeType.Cube:
                        DrawCube(shape.Size);
                        break;
                    case ShapeType.Sphere:
                        DrawSphere(shape.Size);
                        break;
                    case ShapeType.Pyramid:
                        DrawPyramid(shape.Size);
                        break;
                    case ShapeType.Fractal:
                        DrawFractal(shape.Size);
                        break;
                    case ShapeType.ComplexTriangle:
                        DrawComplexTriangle(shape.Size);
                        break;
                }

                glPopMatrix();
            }
        }

        private void DrawBoundaryLimits()
        {
            glColor3d(1.0, 0.0, 0.0); // Красные "стенки"

            glBegin(GL_LINES);

            // Линии по X
            glVertex3d(-boundaryX, -boundaryY, 0);
            glVertex3d(boundaryX, -boundaryY, 0);

            glVertex3d(-boundaryX, boundaryY, 0);
            glVertex3d(boundaryX, boundaryY, 0);

            // Линии по Y
            glVertex3d(-boundaryX, -boundaryY, 0);
            glVertex3d(-boundaryX, boundaryY, 0);

            glVertex3d(boundaryX, -boundaryY, 0);
            glVertex3d(boundaryX, boundaryY, 0);

            glEnd();
        }
        #endregion

        #region Примитивы (куб, сфера, пирамида, фрактал, сложный треугольник)
        private void DrawCube(double size)
        {
            glBegin(GL_QUADS);

            // Передняя грань
            glVertex3d(-size, -size, size);
            glVertex3d(size, -size, size);
            glVertex3d(size, size, size);
            glVertex3d(-size, size, size);

            // Задняя грань
            glVertex3d(-size, -size, -size);
            glVertex3d(-size, size, -size);
            glVertex3d(size, size, -size);
            glVertex3d(size, -size, -size);

            // Верх
            glVertex3d(-size, size, -size);
            glVertex3d(-size, size, size);
            glVertex3d(size, size, size);
            glVertex3d(size, size, -size);

            // Низ
            glVertex3d(-size, -size, -size);
            glVertex3d(size, -size, -size);
            glVertex3d(size, -size, size);
            glVertex3d(-size, -size, size);

            // Правая грань
            glVertex3d(size, -size, -size);
            glVertex3d(size, size, -size);
            glVertex3d(size, size, size);
            glVertex3d(size, -size, size);

            // Левая грань
            glVertex3d(-size, -size, -size);
            glVertex3d(-size, -size, size);
            glVertex3d(-size, size, size);
            glVertex3d(-size, size, -size);

            glEnd();
        }

        private void DrawSphere(double size)
        {
            const int stacks = 18;
            const int slices = 36;

            for (int i = 0; i < stacks; i++)
            {
                double latitude1 = Math.PI * (-0.5 + (double)i / stacks);
                double latitude2 = Math.PI * (-0.5 + (double)(i + 1) / stacks);
                double sinLat1 = Math.Sin(latitude1);
                double cosLat1 = Math.Cos(latitude1);
                double sinLat2 = Math.Sin(latitude2);
                double cosLat2 = Math.Cos(latitude2);

                glBegin(GL_QUAD_STRIP);
                for (int j = 0; j <= slices; j++)
                {
                    double longitude = 2 * Math.PI * (double)j / slices;
                    double sinLon = Math.Sin(longitude);
                    double cosLon = Math.Cos(longitude);

                    double x1 = cosLon * cosLat1;
                    double y1 = sinLon * cosLat1;
                    double z1 = sinLat1;
                    double x2 = cosLon * cosLat2;
                    double y2 = sinLon * cosLat2;
                    double z2 = sinLat2;

                    glVertex3d(size * x1, size * y1, size * z1);
                    glVertex3d(size * x2, size * y2, size * z2);
                }
                glEnd();
            }
        }

        private void DrawPyramid(double size)
        {
            // Треугольные стороны
            glBegin(GL_TRIANGLES);

            // Перед
            glVertex3d(0, size, 0);
            glVertex3d(-size, -size, size);
            glVertex3d(size, -size, size);

            // Правая
            glVertex3d(0, size, 0);
            glVertex3d(size, -size, size);
            glVertex3d(size, -size, -size);

            // Задняя
            glVertex3d(0, size, 0);
            glVertex3d(size, -size, -size);
            glVertex3d(-size, -size, -size);

            // Левая
            glVertex3d(0, size, 0);
            glVertex3d(-size, -size, -size);
            glVertex3d(-size, -size, size);

            glEnd();

            // Основание (квадрат)
            glBegin(GL_QUADS);
            glVertex3d(-size, -size, size);
            glVertex3d(size, -size, size);
            glVertex3d(size, -size, -size);
            glVertex3d(-size, -size, -size);
            glEnd();
        }

        /// <summary>
        /// Пример простого фрактала (рекурсивный треугольник).
        /// Можно заменить на любой более «эффектный» алгоритм.
        /// </summary>
        private void DrawFractal(double size)
        {
            // Для красоты чуть уменьшим
            size *= 2.0;

            // Рисуем "треугольник Серпинского" в 2D-плоскости
            glPushMatrix();
            glRotated(-90, 1, 0, 0); // Повернём "плашмя", чтобы смотреть "сверху"

            // Примитивный рекурсивный метод
            SierpinskiTriangle(0, 0, size, 3);

            glPopMatrix();
        }

        private void SierpinskiTriangle(double x, double y, double size, int level)
        {
            if (level <= 0)
            {
                return;
            }

            if (level == 1)
            {
                // Рисуем простой равносторонний треугольник
                glBegin(GL_TRIANGLES);
                glVertex3d(x, y, 0);
                glVertex3d(x + size, y, 0);
                glVertex3d(x + size / 2, y + (Math.Sqrt(3) * size / 2), 0);
                glEnd();
            }
            else
            {
                // Делим треугольник на 3 поменьше
                double half = size / 2;
                // Треугольник слева
                SierpinskiTriangle(x, y, half, level - 1);
                // Треугольник справа
                SierpinskiTriangle(x + half, y, half, level - 1);
                // Треугольник вверху
                SierpinskiTriangle(x + half / 2, y + (Math.Sqrt(3) * half / 2), half, level - 1);
            }
        }

        /// <summary>
        /// Отдельная фигура - "сложный треугольник".
        /// Вы можете добавить туда ещё треугольников, чтобы сделать его по-настоящему "сложным".
        /// </summary>
        private void DrawComplexTriangle(double size)
        {
            glBegin(GL_TRIANGLES);

            // Первый треугольник
            glVertex3d(0, size, 0);
            glVertex3d(-size, -size, size);
            glVertex3d(size, -size, size);

            // Второй треугольник
            glVertex3d(0, size, 0);
            glVertex3d(size, -size, size);
            glVertex3d(size, -size, -size);

            // Третий - для симметрии
            glVertex3d(0, size, 0);
            glVertex3d(size, -size, -size);
            glVertex3d(-size, -size, -size);

            // Четвёртый
            glVertex3d(0, size, 0);
            glVertex3d(-size, -size, -size);
            glVertex3d(-size, -size, size);

            glEnd();
        }
        #endregion

        #region Служебное
        private void OnResize(object sender, EventArgs e)
        {
            UpdateBoundaries();
        }

        private void UpdateBoundaries()
        {
            boundaryX = Width / 20.0;
            boundaryY = Height / 20.0;
        }

        /// <summary>
        /// Закрытие заставки по Esc
        /// </summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Application.Exit();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // Класс, описывающий двигающуюся и вращающуюся фигуру.
        private class MovingShape
        {
            public double X { get; set; }
            public double Y { get; set; }
            public double Z { get; set; }
            public double DX { get; set; }
            public double DY { get; set; }
            public double DZ { get; set; }
            public double Size { get; set; }
            public double Rotation { get; set; }
            public double RotationSpeed { get; set; }
            public double[] Color { get; set; }
            public ShapeType ShapeType { get; set; }

            // Добавляем ось вращения
            public double RotAxisX { get; set; }
            public double RotAxisY { get; set; }
            public double RotAxisZ { get; set; }
        }

        // Расширяем enum ShapeType:
        private enum ShapeType
        {
            Cube,
            Sphere,
            Pyramid,
            Fractal,
            ComplexTriangle // новый пункт
        }
        #endregion
    }
}
