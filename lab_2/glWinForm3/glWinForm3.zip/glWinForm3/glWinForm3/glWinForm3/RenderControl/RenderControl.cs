﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Windows.Forms;

namespace glWinForm3
{
    public partial class RenderControl : OpenGL
    {
        private Control glControl;
        private int horizontalTiles = 1;
        private int verticalTiles = 1;
        private readonly Color[] tileColors = { Color.Red, Color.White, Color.Green, Color.White, Color.Yellow, Color.Blue }; // Цвета для треугольников: левый нижний, левый верхний, верхний центральный, правый верхний, правый нижний, нижний центральный
        private float tileSize = 50.0f; // Сторона шестиугольника

        public RenderControl()
        {
            InitializeComponent();
            SetupGLControl();
        }

        private void SetupGLControl()
        {
            glControl = new Control();
            glControl.TabStop = true;
            glControl.Dock = DockStyle.Fill;
            glControl.Paint += GlControl_Paint;
            glControl.Resize += GlControl_Resize;
            glControl.KeyDown += GlControl_KeyDown;
            glControl.MouseClick += GlControl_MouseClick;
            this.Controls.Add(glControl);
        }

        private void GlControl_Resize(object sender, EventArgs e)
        {
            SetOrthographicProjection(glControl.Width, glControl.Height);
            glControl.Invalidate();
        }

        private void SetOrthographicProjection(int width, int height)
        {
            // Реализация ортографической проекции для корректного рендеринга
            float aspectRatio = (float)width / height;
            float orthoWidth = tileSize * horizontalTiles * 1.5f;
            float orthoHeight = tileSize * verticalTiles * (float)Math.Sqrt(3);

            if (aspectRatio > 1)
            {
                orthoWidth *= aspectRatio;
            }
            else
            {
                orthoHeight /= aspectRatio;
            }

            Debug.WriteLine($"Setting orthographic projection for width {width}, height {height}, orthoWidth {orthoWidth}, orthoHeight {orthoHeight}");
        }

        private void GlControl_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.Black);
            DrawHexagonTiling(e.Graphics);
        }

        private void DrawHexagonTiling(Graphics graphics)
        {
            float hexHeight = (float)(Math.Sqrt(3) * tileSize);
            float startX = (glControl.Width - (horizontalTiles * tileSize * 1.5f)) / 2;
            float startY = (glControl.Height - (verticalTiles * (float)(Math.Sqrt(3) * tileSize))) / 2;

            for (int i = 0; i < verticalTiles; i++)
            {
                for (int j = 0; j < horizontalTiles; j++)
                {
                    float xOffset = j * tileSize * 1.5f;
                    float yOffset = i * hexHeight;
                    if (j % 2 == 1)
                    {
                        yOffset += hexHeight / 2;
                    }
                    DrawHexagonWithTriangleStrip(graphics, startX + xOffset, startY + yOffset, tileSize);
                }
            }
        }

        private void DrawHexagonWithTriangleStrip(Graphics graphics, float x, float y, float size)
        {
            PointF[] hexagonPoints = new PointF[6];
            for (int i = 0; i < 6; i++)
            {
                float angle = (float)(-Math.PI / 3 * i);
                hexagonPoints[i] = new PointF(
                    x + size * (float)Math.Cos(angle),
                    y + size * (float)Math.Sin(angle)
                );
            }

            // Используем Triangle Strip для создания шестиугольника из треугольников
            // Установка цветов для каждого треугольника по часовой стрелке, начиная с верхней секции
            for (int i = 0; i < 6; i++)
            {
                using (Brush brush = new SolidBrush(tileColors[i % tileColors.Length]))
                {
                    PointF[] triangleStrip = { new PointF(x, y), hexagonPoints[i], hexagonPoints[(i + 1) % 6] };
                    graphics.FillPolygon(brush, triangleStrip);
                }
                using (Pen pen = new Pen(Color.Black, 2))
                {
                    graphics.DrawPolygon(pen, new PointF[] { new PointF(x, y), hexagonPoints[i], hexagonPoints[(i + 1) % 6] });
                }
            }
        }

        private void GlControl_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    verticalTiles++;
                    break;
                case Keys.Down:
                    if (verticalTiles > 1) verticalTiles--;
                    break;
                case Keys.Left:
                    if (horizontalTiles > 1) horizontalTiles--;
                    break;
                case Keys.Right:
                    horizontalTiles++;
                    break;
            }
            glControl.Invalidate();
        }

        private void GlControl_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                horizontalTiles++;
                verticalTiles++;
            }
            else if (e.Button == MouseButtons.Right)
            {
                if (horizontalTiles > 1) horizontalTiles--;
                if (verticalTiles > 1) verticalTiles--;
            }
            glControl.Invalidate();
        }

        private void OnRender(object sender, EventArgs e)
        {
            glControl.Invalidate();
        }
    }
}
