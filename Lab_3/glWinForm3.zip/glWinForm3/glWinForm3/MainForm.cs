﻿using System.Windows.Forms;
using static glWinForm3.OpenGL;


namespace glWinForm3
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
    }
}
