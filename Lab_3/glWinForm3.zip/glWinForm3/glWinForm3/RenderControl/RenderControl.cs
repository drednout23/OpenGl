﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Windows.Forms;

namespace glWinForm3
{
    public partial class RenderControl : OpenGL
    {
        private Control glControl;
        private float Xmin = -5.0f;
        private float Xmax = 5.0f;
        private float Ymin;
        private float Ymax;
        private int numberOfPoints = 300;
        private Func<float, float> functionToPlot = x => (float)(Math.Pow(Math.Sin(3 * x) + 1.5, Math.Cos(2 * x)) - 1);

        private Panel controlPanel;
        private NumericUpDown numXmin;
        private NumericUpDown numXmax;
        private NumericUpDown numPoints;
        private Label labelXmin;
        private Label labelXmax;
        private Label labelPoints;
        private Button btnShowPoint;
        private Button btnReset;

        private PointF? highlightedPoint = null;
        private bool isBehavioralGraph = true;

        public RenderControl()
        {
            CustomInitializeComponent();
            SetupGLControl();
            SetupUIControls();
            DrawBehavioralGraph();
        }

        private void CustomInitializeComponent()
        {
            this.SuspendLayout();
            // 
            // RenderControl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = Color.SlateGray;
            this.ForeColor = Color.White;
            this.Name = "RenderControl";
            this.Size = new Size(900, 600);
            this.ResumeLayout(false);
        }

        private void SetupGLControl()
        {
            glControl = new Control();
            glControl.TabStop = true;
            glControl.Dock = DockStyle.Fill;
            glControl.Paint += GlControl_Paint;
            glControl.Resize += GlControl_Resize;
            this.Controls.Add(glControl);
        }

        private void SetupUIControls()
        {
            // Setup panel for controls
            controlPanel = new Panel()
            {
                Dock = DockStyle.Right,
                Size = new Size(150, this.Height),
                BackColor = Color.LightGray
            };

            // Setup NumericUpDowns and Labels for Xmin, Xmax, and Points
            numXmin = new NumericUpDown()
            {
                Minimum = -100,
                Maximum = 100,
                DecimalPlaces = 2,
                Increment = 0.1M,
                Value = (decimal)Xmin,
                Location = new Point(10, 20),
                Size = new Size(60, 20)
            };
            numXmin.ValueChanged += (s, e) => { Xmin = (float)numXmin.Value; AdjustGraphToFit(); glControl.Invalidate(); };

            numXmax = new NumericUpDown()
            {
                Minimum = -100,
                Maximum = 100,
                DecimalPlaces = 2,
                Increment = 0.1M,
                Value = (decimal)Xmax,
                Location = new Point(10, 60),
                Size = new Size(60, 20)
            };
            numXmax.ValueChanged += (s, e) => { Xmax = (float)numXmax.Value; AdjustGraphToFit(); glControl.Invalidate(); };

            numPoints = new NumericUpDown()
            {
                Minimum = 10,
                Maximum = 1000,
                Value = numberOfPoints,
                Location = new Point(10, 100),
                Size = new Size(60, 20)
            };
            numPoints.ValueChanged += (s, e) => { numberOfPoints = (int)numPoints.Value; AdjustGraphToFit(); glControl.Invalidate(); };

            labelXmin = new Label()
            {
                Text = "Xmin",
                Location = new Point(80, 20),
                Size = new Size(50, 20)
            };

            labelXmax = new Label()
            {
                Text = "Xmax",
                Location = new Point(80, 60),
                Size = new Size(50, 20)
            };

            labelPoints = new Label()
            {
                Text = "Points",
                Location = new Point(80, 100),
                Size = new Size(50, 20)
            };

            // Setup buttons for showing point and resetting graph
            btnShowPoint = new Button()
            {
                Text = "Show Point",
                Location = new Point(10, 140),
                Size = new Size(100, 30)
            };
            btnShowPoint.Click += BtnShowPoint_Click;

            btnReset = new Button()
            {
                Text = "Reset",
                Location = new Point(10, 180),
                Size = new Size(100, 30)
            };
            btnReset.Click += BtnReset_Click;

            // Add controls to the panel
            controlPanel.Controls.Add(numXmin);
            controlPanel.Controls.Add(numXmax);
            controlPanel.Controls.Add(numPoints);
            controlPanel.Controls.Add(labelXmin);
            controlPanel.Controls.Add(labelXmax);
            controlPanel.Controls.Add(labelPoints);
            controlPanel.Controls.Add(btnShowPoint);
            controlPanel.Controls.Add(btnReset);

            // Add panel to the form
            this.Controls.Add(controlPanel);
        }

        private void BtnShowPoint_Click(object sender, EventArgs e)
        {
            float x = (Xmin + Xmax) / 2; // User-defined point can be implemented here
            highlightedPoint = new PointF(x, functionToPlot(x));
            isBehavioralGraph = false;
            glControl.Invalidate();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            highlightedPoint = null;
            DrawBehavioralGraph();
        }

        private void DrawBehavioralGraph()
        {
            Xmin = -5.0f;
            Xmax = 5.0f;
            numXmin.Value = (decimal)Xmin;
            numXmax.Value = (decimal)Xmax;
            numberOfPoints = 300;
            numPoints.Value = numberOfPoints;
            isBehavioralGraph = true;
            AdjustGraphToFit();
            glControl.Invalidate();
        }

        private void GlControl_Resize(object sender, EventArgs e)
        {
            AdjustGraphToFit();
            glControl.Invalidate();
        }

        private void SetOrthographicProjection(int width, int height)
        {
            Debug.WriteLine($"Setting orthographic projection for width {width} and height {height}");
        }

        private void GlControl_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
            DrawGraph(e.Graphics);
        }

        private void DrawGraph(Graphics graphics)
        {
            float h = (Xmax - Xmin) / (numberOfPoints - 1);
            List<PointF> points = new List<PointF>();

            // Compute Ymin and Ymax for automatic scaling
            Ymin = float.MaxValue;
            Ymax = float.MinValue;

            for (int i = 0; i < numberOfPoints; i++)
            {
                float x = Xmin + i * h;
                float y = functionToPlot(x);
                points.Add(new PointF(x, y));

                if (y < Ymin) Ymin = y;
                if (y > Ymax) Ymax = y;
            }

            // Set scaling factors to fit graph into the control's drawing area
            float scaleX = (glControl.Width * 0.4f) / (Xmax - Xmin); // Reduce scale to make graph smaller initially
            float scaleY = (glControl.Height * 0.4f) / (Ymax - Ymin);

            // Ensure the graph is centered within the control
            float offsetX = glControl.Width / 2 - ((Xmax + Xmin) / 2) * scaleX;
            float offsetY = glControl.Height / 2 + ((Ymax + Ymin) / 2) * scaleY;

            // Draw coordinate axes
            Pen axisPen = new Pen(Color.Black, 2);
            graphics.DrawLine(axisPen, 0, glControl.Height / 2, glControl.Width, glControl.Height / 2); // X-axis
            graphics.DrawLine(axisPen, glControl.Width / 2, 0, glControl.Width / 2, glControl.Height); // Y-axis

            // Draw the function
            Pen graphPen = new Pen(Color.Red, 1);
            for (int i = 0; i < points.Count - 1; i++)
            {
                float x1 = offsetX + (points[i].X - Xmin) * scaleX;
                float y1 = offsetY - (points[i].Y - Ymin) * scaleY;
                float x2 = offsetX + (points[i + 1].X - Xmin) * scaleX;
                float y2 = offsetY - (points[i + 1].Y - Ymin) * scaleY;
                graphics.DrawLine(graphPen, x1, y1, x2, y2);
            }

            // Draw highlighted point if any
            if (highlightedPoint.HasValue && !isBehavioralGraph)
            {
                PointF p = highlightedPoint.Value;
                float x = offsetX + (p.X - Xmin) * scaleX;
                float y = offsetY - (p.Y - Ymin) * scaleY;
                graphics.FillEllipse(Brushes.Green, x - 5, y - 5, 10, 10);
            }
        }

        private void OnRender(object sender, EventArgs e)
        {
            glControl.Invalidate();
        }

        private void AdjustGraphToFit()
        {
            // Adjust scaling to ensure the graph always fits within the viewport
            SetOrthographicProjection(glControl.Width, glControl.Height);
        }
    }
}
